// Demostración sin llamadas ni claves: los tiempos son simulados, no Whisper.
import {mkdir, writeFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {captionsFromWords} from '../lib/timing.mjs';
import {renderVideo} from './render.mjs';
const root = fileURLToPath(new URL('../', import.meta.url));
const narration = '¿Sabías que un día en Venus dura más que su año? Venus tarda unos doscientos cuarenta y tres días terrestres en completar una vuelta sobre sí mismo. Sin embargo, necesita solo unos doscientos veinticinco para dar una vuelta alrededor del Sol. Además, gira en sentido contrario al de la mayoría de los planetas. Pero hay un detalle: hablamos del giro respecto a las estrellas. El tiempo entre dos amaneceres es distinto. En Venus, incluso una pregunta tan sencilla como cuánto dura un día tiene una respuesta sorprendente.';
const tokens = narration.split(/\s+/);
const words = tokens.map((word, i) => ({word, start: .5 + i * 39 / tokens.length, end: .5 + (i + .85) * 39 / tokens.length}));
const props = {title: 'Un día más largo que un año', object: 'planet', accent: 'cyan', narration, captions: captionsFromWords(words), demo: true};
await mkdir(path.join(root, 'public/jobs/demo'), {recursive: true});
await mkdir(path.join(root, 'output'), {recursive: true});
const propsFile = path.join(root, 'public/jobs/demo/props.json');
await writeFile(propsFile, JSON.stringify(props, null, 2));
await writeFile(path.join(root, 'output/latest.json'), JSON.stringify({propsFile: 'public/jobs/demo/props.json'}, null, 2));
console.log('Demo sin voz; subtítulos con tiempos simulados.');
if (!process.argv.includes('--no-render')) await renderVideo(propsFile, path.join(root, 'output/demo.mp4'));
