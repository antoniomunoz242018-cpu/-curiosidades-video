# Curiosidades verticales con Remotion

Proyecto Node.js + TypeScript/React que recibe un tema y produce un MP4 vertical de **1080 × 1920, 30 fps y 40 segundos**. Fondo oscuro, objeto vectorial animado en el centro, subtítulos grandes con palabra activa resaltada y voz en español.

## Requisitos

- Node.js 22 o superior y npm.
- FFmpeg y ffprobe en el PATH. Ubuntu/Debian: `sudo apt-get install ffmpeg`. macOS: `brew install ffmpeg`.
- Acceso a las APIs de OpenAI con saldo disponible. Las llamadas tienen coste.
- Chrome Headless Shell se descarga en el primer render. En Linux puede requerir bibliotecas del sistema; consulta https://www.remotion.dev/docs/miscellaneous/linux-dependencies. Puedes usar un Chromium instalado con `CHROME_EXECUTABLE`.

## Instalación

```bash
cd curiosidades-video
npm ci
cp .env.example .env
```

El proyecto ya incluye un `.env` vacío como punto de partida. Edita ese archivo:

```dotenv
OPENAI_API_KEY=tu_clave_real
LLM_MODEL=gpt-4o-mini
TTS_MODEL=tts-1
TTS_VOICE=nova
WHISPER_MODEL=whisper-1
```

`LLM_API_KEY`, `TTS_API_KEY` y `WHISPER_API_KEY` permiten cuentas distintas; si están vacías se utiliza `OPENAI_API_KEY`. No se incluyen claves reales. `.env` está excluido de Git; nunca lo publiques ni pongas claves en `src/` o `public/`. Las APIs se llaman únicamente desde Node, no desde React.

## Generar el video

```bash
npm run generate -- "Por qué un día en Venus dura más que su año"
```

El comando muestra la ruta del MP4 en `output/<id>.mp4`. Cada ejecución mantiene sus propios archivos:

```text
public/jobs/<id>/
  script.json          # Tema, título, narración, objeto y color
  voice-raw.mp3        # Respuesta del TTS
  voice.wav            # Audio final de 40 segundos
  transcription.json  # Palabras y tiempos de Whisper
  props.json           # Datos usados por Remotion
output/<id>.mp4
output/latest.json     # Referencia al último trabajo preparado
```

Los archivos en `public/` se sirven al abrir Studio: no incluyas datos privados en los temas o guiones. No hay subida automática a redes sociales.

### Revisar antes del render

```bash
npm run generate -- "Los cristales de cuarzo" --no-render
npm run studio -- --props=public/jobs/ID/props.json
```

Sustituye `ID` por el identificador mostrado. Puedes editar el título, color, objeto o subtítulos en `props.json` y renderizar sin repetir llamadas:

```bash
npm run render -- public/jobs/ID/props.json output/mi-video.mp4
```

`npm run render` sin argumentos renderiza el último trabajo preparado en `output/video.mp4`. Studio sin `--props` muestra solo la composición de ejemplo. Si cambias la narración, vuelve a generar voz y transcripción; editar solo el texto no cambia el audio.

### Demo sin claves

```bash
npm run demo
```

Genera `output/demo.mp4` con la misma composición y duración. **La demo no tiene voz y usa tiempos simulados; no ejecuta Whisper ni llamadas externas.** `npm run demo -- --no-render` prepara solo las props para revisarlas en Studio:

```bash
npm run studio -- --props=public/jobs/demo/props.json
```

## Flujo

1. El LLM devuelve un JSON validado con título, narración en español de unas 88–100 palabras, objeto y acento de color.
2. TTS (`tts-1`, voz `nova` por defecto) sintetiza la narración.
3. FFmpeg ajusta la voz a 39 segundos con `atempo`, añade 0,5 segundos al principio y al final y produce un WAV mono de 24 kHz. Se rechazan ajustes extremos para conservar inteligibilidad.
4. Whisper (`whisper-1`, `verbose_json` y marcas por palabra) transcribe **el audio ya ajustado**. Los subtítulos se agrupan en frases cortas y cada palabra se resalta según su marca real; no se calculan a partir de la longitud del texto.
5. Remotion renderiza 1.200 frames con H.264, AAC cuando hay voz y píxeles `yuv420p` para compatibilidad móvil. FFmpeg finaliza el contenedor a 40 segundos, ajusta el relleno AAC y añade `faststart` sin recodificar el video.

La duración del video es fija; el audio se ajusta a ella. Los tiempos de Whisper son estimaciones: conviene revisar nombres propios, silencios y números. La exactitud factual del LLM tampoco está garantizada; revisa el guion antes de publicar.

Los objetos son ilustraciones SVG procedurales incluidas: `planet`, `atom`, `bulb`, `brain`, `crystal` y `ocean`. No se descargan imágenes ni se genera un modelo 3D del tema. Para añadir objetos, edita `src/Object.tsx` y amplía los tipos y el esquema del guion. Paletas: `cyan`, `violet` y `amber`.

## Verificación

```bash
npm run check
npm test
ffprobe -v error -show_entries stream=codec_name,width,height,r_frame_rate -show_entries format=duration -of json output/mi-video.mp4
```

El video debe indicar `1080`, `1920`, `30/1` y duración `40.000000`. Las pruebas verifican el ajuste de velocidad, la duración real del WAV con FFmpeg y la agrupación y límites de los subtítulos. La demo verifica el render sin credenciales; la integración real requiere claves.

## Problemas frecuentes

- **401 / 429:** revisa la clave, acceso al modelo, saldo y límites. Los clientes reintentan errores transitorios hasta dos veces.
- **FFmpeg no encontrado:** instala FFmpeg y comprueba `ffmpeg -version` y `ffprobe -version`.
- **Chrome no inicia:** instala las dependencias de Linux o configura `CHROME_EXECUTABLE`. No desactives la verificación TLS para descargarlo.
- **Memoria limitada:** usa `RENDER_CONCURRENCY=1` en `.env`.
- **Voz demasiado larga/corta:** el proceso conserva `script.json` y `voice-raw.mp3` y se detiene si necesita un cambio de velocidad fuera de 0,7–1,4. Ajusta el prompt o la voz y vuelve a ejecutar.
- **Modelo Whisper incompatible:** mantén `whisper-1`; otros modelos pueden no soportar marcas de tiempo por palabra.

Remotion tiene condiciones de licencia según uso y tamaño de la organización: https://www.remotion.dev/license.
