export type Word = {text: string; start: number; end: number};
export type VideoProps = {
  title: string;
  narration: string;
  object: 'planet' | 'atom' | 'bulb' | 'brain' | 'crystal' | 'ocean';
  accent: 'cyan' | 'violet' | 'amber';
  audioSrc?: string;
  captions: {start: number; end: number; words: Word[]}[];
  demo: boolean;
};
